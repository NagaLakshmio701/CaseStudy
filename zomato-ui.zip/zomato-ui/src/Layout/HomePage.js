import React from "react";
import { Link, Outlet } from "react-router-dom";
import { Navbar, Nav, Container, Row, Col, Button, Card } from 'react-bootstrap';
import Footer from "./Footer";
import HomeContent from "./HomeItems";
import Header  from "./Header";
import SearchBar from "./SearchBar";

export default function HomePage() {
    
return (

  <div>

       <Header/>
    
      <div><SearchBar/> </div>

        <div>
          <HomeContent/>
        </div>
      

      <main>
        <Outlet /> {/* Outlet is like a placeholder and all requested routes are rendered to the Outlet element */}
      </main>

      <div>
     
       <Footer/>

      </div>
  
  </div>
)
}
