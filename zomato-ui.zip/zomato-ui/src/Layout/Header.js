import { Navbar, Nav,Container, Row, Col, Button, Card } from 'react-bootstrap';
import { Link, Outlet } from "react-router-dom";

const Header=()=>{

    const user = JSON.parse(sessionStorage.getItem('user'));

    return(
        <>
<Navbar bg="light" expand="lg" style={{ padding: '30px 0' }}>
<Container>
  <Navbar.Brand className="mx-auto order-0">Zomato</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="ml-auto ms-auto order-1 order-lg-2">
      {user ? (
        <>
          <Nav.Link>Hello, {user.name}</Nav.Link>
          <Nav.Link as={Link} to="/profile">Profile</Nav.Link>
          <Nav.Link as={Link} to="/logout">Logout</Nav.Link>
        </>
      ) : (
        <>
          <Nav.Link as={Link} to="/login">Login</Nav.Link>
          <Nav.Link as={Link} to="/signup">Signup</Nav.Link>
        </>
      )}
    </Nav>
  </Navbar.Collapse>
</Container>


</Navbar>
</>
    )
}

export default Header;
