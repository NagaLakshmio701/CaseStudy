import { Navbar, Nav,Container, Row, Col, Button, Card } from 'react-bootstrap';
import { Link, Outlet } from "react-router-dom";

const SearchBar=()=>{
    return(
        <>
<div className="hero-section text-center text-white" style={{ backgroundImage: 'url(https://b.zmtcdn.com/web_assets/81f3ff974d82520780078ba1cfbd453a1583259680.png)', padding: '200px 0' }}>
<Container>
  <h2>Discover The Best Food</h2>
  <Row className="justify-content-center mt-4">
    <Col md={6}>
      <div className="input-group">
        <input type="text" className="form-control" placeholder="Search for restaurant or a dish" />
        <div className="input-group-append">
          <Button  variant="danger">Search</Button>
        </div>
      </div>
    </Col>
  </Row>
</Container>
</div>
</>
    )
}

export default SearchBar;