const OwnerDashboard = () => {
    return <h1>OwnerDashboard</h1>;
  };

  export default OwnerDashboard;