import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Logout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Clear session storage
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("user");

    // Redirect to homepage
    navigate("/");
  }, [navigate]);

  return null; // No UI needed, just redirecting
};

export default Logout;
